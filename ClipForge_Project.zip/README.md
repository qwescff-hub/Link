# ClipForge

Mobile-first AI video clipping project.

## What this package contains
- `android/` — lightweight Android WebView app.
- `space/` — free Hugging Face Space backend prototype using yt-dlp, Whisper and FFmpeg.
- `.github/workflows/build-apk.yml` — GitHub Actions workflow that builds the APK.

## Important
The Android app is a client. Heavy YouTube download/transcription/video processing is intended to run in the Space backend, not inside the APK.

Use only videos you own or have permission to process, and comply with the source platform's terms.

## Build
The GitHub Actions workflow builds a debug APK from `android/`.
