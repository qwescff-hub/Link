package com.clipforge.app;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MainActivity extends android.app.Activity {

    private static final String PREFS = "clipforge";
    private static final String URL_KEY = "backend_url";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String savedUrl = prefs.getString(URL_KEY, "");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 48, 32, 32);
        root.setBackgroundColor(Color.rgb(17, 17, 17));

        TextView title = new TextView(this);
        title.setText("ClipForge");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setPadding(0, 0, 0, 16);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Paste your ClipForge backend URL below, then open the clipper.");
        info.setTextColor(Color.LTGRAY);
        info.setTextSize(16);
        info.setPadding(0, 0, 0, 20);
        root.addView(info);

        EditText url = new EditText(this);
        url.setHint("https://your-space.hf.space");
        url.setText(savedUrl);
        url.setSingleLine(true);
        url.setTextColor(Color.WHITE);
        url.setHintTextColor(Color.GRAY);
        root.addView(url, new LinearLayout.LayoutParams(-1, 60));

        Button open = new Button(this);
        open.setText("Open ClipForge");
        root.addView(open, new LinearLayout.LayoutParams(-1, 60));

        TextView note = new TextView(this);
        note.setText("The AI/video processing runs on the configured backend.");
        note.setTextColor(Color.GRAY);
        note.setPadding(0, 24, 0, 0);
        root.addView(note);

        open.setOnClickListener(v -> {
            String target = url.getText().toString().trim();
            if (!(target.startsWith("https://") || target.startsWith("http://"))) {
                Toast.makeText(this, "Enter a valid backend URL.", Toast.LENGTH_SHORT).show();
                return;
            }

            prefs.edit().putString(URL_KEY, target).apply();
            showWebView(target);
        });

        setContentView(root);
    }

    private void showWebView(String target) {
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(17, 17, 17));

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl(target);

        setContentView(web);
    }

    @Override
    public void onBackPressed() {
        View view = getWindow().getDecorView().findViewById(android.R.id.content);
        if (view instanceof WebView) {
            WebView web = (WebView) view;
            if (web.canGoBack()) {
                web.goBack();
                return;
            }
        }
        super.onBackPressed();
    }
}
