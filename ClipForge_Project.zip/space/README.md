---
title: ClipForge AI Clipper
emoji: ✂️
colorFrom: purple
colorTo: blue
sdk: gradio
sdk_version: 5.44.1
app_file: app.py
pinned: false
---

# ClipForge AI Clipper

Prototype backend for authorized video processing.

It downloads a public YouTube URL with yt-dlp, extracts audio, transcribes with Whisper, scores transcript segments, creates short 9:16 clips and burns captions with FFmpeg.

CPU Spaces can be slow. The first version uses Whisper `tiny`.
