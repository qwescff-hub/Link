import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import gradio as gr
import whisper
import yt_dlp

MODEL = whisper.load_model("tiny")


def run(cmd):
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)


def safe_name(text):
    text = re.sub(r"[^a-zA-Z0-9_-]+", "_", text)
    return text[:60] or "clip"


def download_video(url, work):
    out = str(Path(work) / "source.%(ext)s")
    opts = {
        "format": "bestvideo[height<=720]+bestaudio/best[height<=720]/best",
        "outtmpl": out,
        "merge_output_format": "mp4",
        "noplaylist": True,
        "quiet": True,
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
    mp4 = next(Path(work).glob("source.*"))
    return str(mp4), info.get("title", "ClipForge Video")


def make_srt(segments, start, end, path):
    lines = []
    idx = 1
    for seg in segments:
        a = max(seg["start"], start)
        b = min(seg["end"], end)
        if b <= a:
            continue
        text = seg["text"].strip()
        if not text:
            continue
        def ts(x):
            h = int(x // 3600)
            m = int((x % 3600) // 60)
            s = int(x % 60)
            ms = int((x - int(x)) * 1000)
            return f"{h:02}:{m:02}:{s:02},{ms:03}"
        lines.append(f"{idx}\n{ts(a-start)} --> {ts(b-start)}\n{text}\n")
        idx += 1
    Path(path).write_text("\n".join(lines), encoding="utf-8")


def create_clip(source, title, segments, start, end, out):
    srt = str(Path(out).with_suffix(".srt"))
    make_srt(segments, start, end, srt)

    vf = (
        "crop=ih*9/16:ih:(iw-ih*9/16)/2:0,"
        "scale=1080:1920:force_original_aspect_ratio=decrease,"
        "pad=1080:1920:(ow-iw)/2:(oh-ih)/2:black"
    )

    if Path(srt).exists() and Path(srt).read_text(encoding="utf-8").strip():
        srt_filter = srt.replace("\\", "/").replace(":", "\\:")
        vf += f",subtitles='{srt_filter}':force_style='FontSize=20,Outline=2,Alignment=2,MarginV=120'"

    run([
        "ffmpeg", "-y", "-ss", str(start), "-to", str(end),
        "-i", source,
        "-vf", vf,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "25",
        "-c:a", "aac", "-b:a", "128k",
        out
    ])
    return out


def clipforge(url, number_of_clips, clip_seconds, progress=gr.Progress()):
    if not url or "youtube.com" not in url and "youtu.be" not in url:
        raise gr.Error("Please enter a YouTube URL.")

    number_of_clips = int(number_of_clips)
    clip_seconds = int(clip_seconds)

    work = tempfile.mkdtemp(prefix="clipforge_")
    outputs = []

    try:
        progress(0.1, desc="Downloading video...")
        source, title = download_video(url, work)

        progress(0.3, desc="Finding strong moments...")
        result = MODEL.transcribe(source, fp16=False, verbose=False)
        segments = result.get("segments", [])

        if not segments:
            raise gr.Error("No speech segments were detected.")

        # Simple moment scoring: speech activity + segment length.
        scored = []
        for i, seg in enumerate(segments):
            length = max(0.1, seg["end"] - seg["start"])
            score = min(length, 12.0)
            text = seg["text"].strip()
            score += min(len(text) / 45.0, 4.0)
            if "?" in text:
                score += 1.0
            scored.append((score, i, seg))

        scored.sort(reverse=True)
        chosen = []
        for score, _, seg in scored:
            center = (seg["start"] + seg["end"]) / 2
            start = max(0, center - clip_seconds / 2)
            end = start + clip_seconds

            # Avoid heavily overlapping selections.
            if all(abs(((a+b)/2) - center) > clip_seconds * 0.8 for a, b in chosen):
                chosen.append((start, end))
            if len(chosen) >= number_of_clips:
                break

        if not chosen:
            raise gr.Error("Could not choose clip moments.")

        progress(0.55, desc="Editing vertical clips...")
        for idx, (start, end) in enumerate(chosen, 1):
            out = str(Path(work) / f"{safe_name(title)}_{idx}.mp4")
            create_clip(source, title, segments, start, end, out)
            outputs.append(out)
            progress(0.55 + 0.4 * idx / len(chosen), desc=f"Creating clip {idx}...")

        return outputs

    finally:
        # Keep returned files available to Gradio; its File component copies them.
        pass


with gr.Blocks(title="ClipForge AI Clipper") as demo:
    gr.Markdown(
        "# ✂️ ClipForge\n"
        "Paste a YouTube link to find strong speech moments and create captioned 9:16 clips.\n\n"
        "**Use only videos you own or are authorized to process.**"
    )

    with gr.Row():
        url = gr.Textbox(label="YouTube URL", placeholder="https://www.youtube.com/watch?v=...")
    with gr.Row():
        count = gr.Slider(1, 5, value=3, step=1, label="Number of clips")
        length = gr.Slider(15, 60, value=30, step=5, label="Clip length (seconds)")

    go = gr.Button("Create Clips", variant="primary")
    files = gr.Files(label="Finished MP4 clips", file_count="multiple")

    go.click(
        clipforge,
        inputs=[url, count, length],
        outputs=files,
    )

if __name__ == "__main__":
    demo.launch()
